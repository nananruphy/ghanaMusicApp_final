package com.example.ghanamusicapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Reggae extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        ArrayList<Music> music = new ArrayList<Music>();
        music.add(new Music("Rocky Dawuni", "The Movement     1996"));
        music.add(new Music("Rocky Dawuni", "Crusade     1998"));
        music.add(new Music("Rocky Dawuni", "Book of Changes     2005"));
        music.add(new Music("Rocky Dawuni", "Branches of The Same Tree     2015"));
        music.add(new Music("Rocky Dawuni", "Beats of Zion    2019"));
        music.add(new Music("Blakk Rasta", "The Rasta Shrine    2000"));
        music.add(new Music("Blakk Rasta", "Ganja Minister   2004"));
        music.add(new Music("Blakk Rasta", "Born Dread    2011"));
        music.add(new Music("Black Prophet", "Doubting Me   2006"));
        music.add(new Music("Black Prophet", "Times like this    2016"));
        music.add(new Music("Rocky Dawuni", "The Movement     1996"));
        music.add(new Music("Rocky Dawuni", "Crusade     1998"));
        music.add(new Music("Rocky Dawuni", "Book of Changes     2005"));
        music.add(new Music("Rocky Dawuni", "Branches of The Same Tree     2015"));
        music.add(new Music("Rocky Dawuni", "Beats of Zion    2019"));
        music.add(new Music("Blakk Rasta", "The Rasta Shrine    2000"));
        music.add(new Music("Blakk Rasta", "Ganja Minister   2004"));
        music.add(new Music("Blakk Rasta", "Born Dread    2011"));
        music.add(new Music("Black Prophet", "Doubting Me   2006"));
        music.add(new Music("Black Prophet", "Times like this    2016"));
        MusicAdapter adapter = new MusicAdapter(this, music);
        ListView listView = (ListView) findViewById(R.id.music_list);
        listView.setAdapter(adapter);
    }
}
