package com.example.ghanamusicapp;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PlaySong extends Activity {
    private Bitmap mImage1;

    public static void setOnClickListener(View.OnClickListener onClickListener) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_song);

        Bundle bundle = getIntent().getExtras();
        ImageView imageView = (ImageView) findViewById(R.id.playSong_imageview);
    }
}