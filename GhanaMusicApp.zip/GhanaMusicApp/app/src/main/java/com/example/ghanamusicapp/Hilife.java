package com.example.ghanamusicapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.View;

import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;

public class Hilife extends AppCompatActivity  {
    private Bitmap mImage1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        ArrayList<Music> music = new ArrayList<Music>();
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        MusicAdapter adapter = new MusicAdapter(this, music);
        ListView listView = (ListView) findViewById(R.id.music_list);
        listView.setAdapter(adapter);

        }

}



