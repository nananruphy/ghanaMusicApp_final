package com.example.ghanamusicapp;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Find the View that shows the hilife music category
        TextView hilife = (TextView) findViewById(R.id.hilife);
        // Set a click listener on that View
        hilife.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the hilife music category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link NumbersActivity}
                Intent hilifeIntent = new Intent(MainActivity.this, Hilife.class);
                // Start the new activity
                startActivity(hilifeIntent);
            }
        });
        // Find the View that shows the reggae music category
        TextView reggae = (TextView) findViewById(R.id.reggae);

        // Set a click listener on that View
        reggae.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the reggae music category is clicked on.
            @Override
            public void onClick(View view) {
                Intent reggaeIntent = new Intent(MainActivity.this, Reggae.class);
                // Start the new activity
                startActivity(reggaeIntent);
            }
        });
        // Find the View that shows the hiplife music category
        TextView hiplife = (TextView) findViewById(R.id.hiplife);
        // Set a click listener on that View
        hiplife.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the hiplife music category is clicked on.
            @Override
            public void onClick(View view) {
                Intent hiplifeIntent = new Intent(MainActivity.this, Hiplife.class);
                // Start the new activity
                startActivity(hiplifeIntent);
            }
        });
        // Find the View that shows the afro music category
        TextView afro = (TextView) findViewById(R.id.afro);
        // Set a click listener on that View
        afro.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the afro music category is clicked on.
            @Override
            public void onClick(View view) {
                Intent afroIntent = new Intent(MainActivity.this, Afro.class);
                startActivity(afroIntent);
            }
        });
    }
}