package com.example.ghanamusicapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Hiplife extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);

        ArrayList<Music> music = new ArrayList<Music>();
        music.add(new Music("Samini", "Next Page     2013"));
        music.add(new Music("Samini", "Breaking News     2015"));
        music.add(new Music("Samini", "Untammed     2018"));
        music.add(new Music("Samini", "Dagaati     2019"));
        music.add(new Music("Sarkodie", "Rapperholic     2019"));
        music.add(new Music("Stonebwoy", "Nominate     2000"));
        music.add(new Music("Stonebwoy", "Activate     2019"));
        music.add(new Music("SStonebwoy", "Ever Lasting    2019"));
        music.add(new Music("Samini", "Next Page     2013"));
        music.add(new Music("Samini", "Breaking News     2015"));
        music.add(new Music("Samini", "Untammed     2018"));
        music.add(new Music("Samini", "Dagaati     2019"));
        music.add(new Music("Sarkodie", "Rapperholic     2019"));
        music.add(new Music("Stonebwoy", "Nominate     2000"));
        music.add(new Music("Stonebwoy", "Activate     2019"));
        music.add(new Music("SStonebwoy", "Ever Lasting    2019"));
        music.add(new Music("Samini", "Next Page     2013"));
        music.add(new Music("Samini", "Breaking News     2015"));
        music.add(new Music("Samini", "Untammed     2018"));
        music.add(new Music("Samini", "Dagaati     2019"));
        music.add(new Music("Sarkodie", "Rapperholic     2019"));
        music.add(new Music("Stonebwoy", "Nominate     2000"));
        music.add(new Music("Stonebwoy", "Activate     2019"));
        music.add(new Music("SStonebwoy", "Ever Lasting    2019"));
        music.add(new Music("Samini", "Next Page     2013"));
        music.add(new Music("Samini", "Breaking News     2015"));
        music.add(new Music("Samini", "Untammed     2018"));
        music.add(new Music("Samini", "Dagaati     2019"));
        music.add(new Music("Sarkodie", "Rapperholic     2019"));
        music.add(new Music("Stonebwoy", "Nominate     2000"));
        music.add(new Music("Stonebwoy", "Activate     2019"));
        music.add(new Music("SStonebwoy", "Ever Lasting    2019"));
        MusicAdapter adapter = new MusicAdapter(this, music);
        ListView listView = (ListView) findViewById(R.id.music_list);
        listView.setAdapter(adapter);
    }
}
